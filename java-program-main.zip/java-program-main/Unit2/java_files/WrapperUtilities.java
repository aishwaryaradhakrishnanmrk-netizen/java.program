public class WrapperUtilities {
    public static void main(String[] args) {
        Integer x = 50;
        System.out.println("Compare: " + x.compareTo(40));
        System.out.println("Binary: " + Integer.toBinaryString(10));
        System.out.println("Max of 10 and 20: " + Integer.max(10, 20));
    }
}
