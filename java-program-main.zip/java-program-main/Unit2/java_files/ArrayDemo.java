public class ArrayDemo {
    public static void main(String[] args) {
        int[] scores = {95, 88, 76, 90, 84};
        System.out.println("Array Elements:");
        for (int i = 0; i < scores.length; i++) {
            System.out.println("Index " + i + ": " + scores[i]);
        }
    }
}
