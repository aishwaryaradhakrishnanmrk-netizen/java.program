
class VariableDemo {
    public static void main(String[] args) {
        int age = 25;               
        double salary = 55000.75;   
        char grade = 'A';           
        boolean isStudent = false;  

        System.out.println("Age: " + age);
        System.out.println("Salary: " + salary);
        System.out.println("Grade: " + grade);
        System.out.println("Is Student: " + isStudent);
    }
}
