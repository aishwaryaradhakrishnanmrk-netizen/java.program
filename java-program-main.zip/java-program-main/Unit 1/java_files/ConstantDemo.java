
class ConstantDemo {
    public static void main(String[] args) {
        final double PI = 3.14159;
        int radius = 5;

        double area = PI * radius * radius;

        System.out.println("Radius: " + radius);
        System.out.println("Area of Circle: " + area);
    }
}
